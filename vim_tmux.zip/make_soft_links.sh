#/bin/bash

git config http.verifyssl false
git clone https://github.com/paansolutions/devcenter.git
ln -s -T devcenter/
ln -s -T devcenter/.vimrc .vimrc
ln -s -T devcenter/.vimcommander.custom .vimcommander.custom
ln -s -T devcenter/tmux-session tmux-session
